<?php

$api = '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';